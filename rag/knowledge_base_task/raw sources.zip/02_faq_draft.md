# Nexus Property Group – Frequently Asked Questions

*Last updated: sometime in 2023 (website team pls confirm exact date – Jess)*
*TODO: merge with the FAQ on the old site before Q3 – Marcus*

---

> **Disclaimer:** The information on this page is provided for general guidance only and may not reflect the most current policies. For official policy, refer to your signed lease agreement or contact your property manager directly.

---

## GENERAL QUESTIONS

**Q: How do I apply for an apartment?**
A: You can apply online at nexuspropertygroup.com/apply or visit our leasing office during business hours (Mon–Fri 9am–6pm, Sat 10am–4pm). All adults 18+ living in the unit must submit a separate application. The application fee is $55 per adult.

**Q: How long does the application process take?**
A: Standard applications are processed in 2–3 business days. We offer expedited 24-hour processing for an additional $30 fee.

*(Note from Marcus: policy doc says $25 for expedited – which is right? Check with Linda before publishing)*

**Q: What credit score do I need to qualify?**
A: We require a minimum credit score of 650. Applicants with scores between 600–649 may still qualify with a larger security deposit.

*(Editor note: THIS IS WRONG – policy manual says 620 minimum, 580–619 with extra deposit. DO NOT PUBLISH until corrected – Jess 11/14/23)*

**Q: Do you accept co-signers?**
A: Yes! Co-signers must meet all income and credit requirements independently.

**Q: What is the income requirement?**
A: Your gross monthly income should be at least 3x the monthly rent. So for a $2,000/month apartment, you'd need to show $6,000/month in gross income.

---

## RENT & PAYMENTS

**Q: When is rent due?**
A: Rent is due on the 1st of the month. We have a 5-day grace period, so as long as we receive it by the 5th, no late fee is charged.

**Q: What happens if I pay rent late?**
A: A $75 late fee is applied on the 6th. If rent is still unpaid after the 10th, an additional $10 per day is added up to a maximum of $250.

*(Note: policy doc says max is $200 – need to reconcile – Marcus)*

**Q: How can I pay my rent?**
A: We accept payments through our online tenant portal, ACH/bank transfer, money order, or cashier's check. We do not accept cash or personal checks.

**Q: Can I pay rent in cash?**
A: No. We do not accept cash payments under any circumstances.

**Q: What happens if my payment is returned (bounced)?**
A: You'll be charged a $35 NSF fee. After 2 returned payments in a 12-month period, you may be required to use money orders or cashier's checks for all future payments.

**Q: Do you have an online portal?**
A: Yes! Visit nexuspropertygroup.com/pay to make payments, submit maintenance requests, and view your lease documents.

---

## SECURITY DEPOSITS

**Q: How much is the security deposit?**
A: Security deposits are generally 1.5x your monthly rent. So for a $2,000/month apartment, the deposit would be $3,000.

**Q: Are deposits refundable?**
A: Yes. Deposits are returned within 21 days of move-out, minus any deductions for unpaid rent, cleaning, or damages beyond normal wear and tear.

**Q: What counts as "normal wear and tear"?**
A: Things like minor wall scuffs, small nail holes, and carpet wear in high-traffic areas are considered normal. Large holes in walls, stains, broken fixtures, or pet damage are not.

**Q: How do I get my deposit back faster?**
A: Complete a thorough move-out cleaning, return all keys and access devices, and submit your forwarding address in writing. Our team will inspect within 5 business days of your move-out date.

**Q: Can you take my deposit for painting?**
A: Normal repainting after a standard tenancy is considered wear and tear and is NOT deductible from your deposit. However, if walls have excessive scuffs, holes, or non-approved paint colors, those costs may be deducted.

---

## LEASE & RENEWALS

**Q: How much notice do I need to give before moving out?**
A: You must provide 60 days written notice before your lease end date (or before vacating if breaking your lease early).

**Q: What is the early termination fee?**
A: The early termination fee is equal to 2 months' rent, plus you must give 60 days notice.

**Q: How much can my rent increase at renewal?**
A: For properties in Coastal City, rent increases are capped at 5% or CPI+2%, whichever is lower, per local ordinance.

**Q: Can I go month-to-month after my lease ends?**
A: In some cases, yes, subject to management approval and a month-to-month surcharge (typically $150–$200/month above your current rent rate). Not all units are eligible. Ask your property manager.

**Q: What if I'm in the military and need to break my lease?**
A: Active duty service members can terminate their lease early without penalty under the Servicemembers' Civil Relief Act (SCRA). Provide your deployment or PCS orders to the leasing office.

---

## PETS

**Q: Are pets allowed?**
A: Yes! We are pet-friendly. Dogs and cats are welcome with prior approval.

**Q: What breeds are restricted?**
A: We restrict the following breeds: Pit Bull Terrier, Rottweiler, Doberman Pinscher, Akita, Chow Chow, and Wolf hybrids (or any mixes of these breeds).

**Q: How many pets can I have?**
A: Maximum 2 pets per unit. For dogs, the combined weight cannot exceed 80 lbs.

**Q: Is there a pet deposit?**
A: Yes. The pet deposit is $300 per pet (refundable).

*(Note: policy doc says $500 per pet – CONFIRM BEFORE PUBLISHING – Jess)*

**Q: Is there monthly pet rent?**
A: Yes: $50/month per dog, $35/month per cat.

**Q: What about service animals or ESAs?**
A: Service animals and emotional support animals are exempt from breed and weight restrictions under the Fair Housing Act. Documentation from a licensed provider is required for ESAs.

**Q: Are pets allowed?**
A: We love pets at Nexus! Dogs and cats are permitted with a signed pet addendum, pet deposit, and monthly pet fee. Please see our full pet policy for details.

*(THIS IS A DUPLICATE – delete one of these – Marcus)*

---

## MAINTENANCE

**Q: How do I submit a maintenance request?**
A: Log into your tenant portal at nexuspropertygroup.com/pay and navigate to "Maintenance." You can also call the office during business hours or use the 24/7 emergency maintenance line for urgent issues.

**Q: What counts as an emergency maintenance issue?**
A: Emergencies include: no heat in winter, flooding or active water leaks, no hot water, gas leaks, sewage backups, or any condition that poses an immediate safety risk. Call our emergency line: (800) 555-0199.

**Q: How long does non-emergency maintenance take?**
A: We aim to respond within 3–5 business days for non-urgent requests. Complex repairs may take longer.

**Q: Can I make repairs myself and deduct the cost from rent?**
A: No. California law allows "repair and deduct" under limited circumstances, but Nexus Property Group policy requires all repairs to be completed by our approved vendors. Unauthorized repairs may result in additional charges. Contact the leasing office before attempting any repairs.

---

## MISCELLANEOUS

**Q: Can I sublet my apartment?**
A: Subletting is not permitted without prior written approval from Nexus Property Group. Unauthorized subletting is grounds for lease termination.

**Q: Can I run a business from my apartment?**
A: Home-based businesses that do not involve client visits, deliveries, or disturbances to other tenants may be permitted. Contact your property manager for written approval.

**Q: Is smoking allowed?**
A: All Nexus Property Group properties are 100% smoke-free, including balconies and common areas. This includes cigarettes, cigars, and marijuana (regardless of legality). Violation may result in lease termination and cleaning fees.

**Q: What is the guest policy?**
A: Guests may stay for up to 14 consecutive days or 30 days total in any 12-month period. Guests staying longer may be required to apply as a resident.

**Q: Can I install a satellite dish or antenna?**
See lease addendum C. ACTUALLY I don't know the answer to this – someone check with legal – Marcus

---

*Questions not answered here? Contact us:*
*leasing@nexuspropertygroup.com | (800) 555-0192*
*Office hours: Mon–Fri 9am–6pm | Sat 10am–4pm*

*[FOOTER: Home | About | Properties | Apply Now | Tenant Portal | Contact | Privacy Policy | Accessibility]*
*© 2023 Nexus Property Group. All rights reserved.*
*This FAQ is for informational purposes only and does not constitute legal advice.*
*Cookie Policy | Terms of Use | Do Not Sell My Personal Information*
