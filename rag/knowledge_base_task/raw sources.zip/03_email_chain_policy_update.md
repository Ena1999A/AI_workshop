# [EMAIL EXPORT] Policy Update Thread – Late Fee Cap & Pet Deposit Changes
*Exported from Outlook by: J. Hoffman | Export date: 2024-01-08*
*Thread ID: NPG-INT-2023-1047 | Participants: 6*

---

------- Original Message -------
From: Linda Vasquez <l.vasquez@nexuspropertygroup.com>
To: Marcus Webb <m.webb@nexuspropertygroup.com>; Jessica Hoffman <j.hoffman@nexuspropertygroup.com>
CC: Robert Tan <r.tan@nexuspropertygroup.com>
Date: Monday, November 6, 2023 9:14 AM
Subject: URGENT: Policy updates needed before Jan 1

Marcus, Jessica,

Following our conversation with legal last week, we need to update two policies before January 1st. I'll summarize what needs to change:

1. **Late fee maximum**: The current policy doc says the max late fee accumulation is $200/month. Legal confirmed this exceeds what's enforceable under the updated Coastal City Tenant Protection Ordinance (effective Jan 1, 2024). The new cap needs to be $150/month. We also need to remove the $10/day language and replace it with a flat structure to reduce ambiguity.

   NEW LATE FEE STRUCTURE (to replace Section 4.2):
   - $75 flat fee on the 6th
   - Additional $75 flat fee if rent is not received by the 15th
   - Total maximum late fee: $150/month
   - No per-day accrual

2. **Pet deposit**: $500 per pet is generating a lot of friction with prospective tenants and we're losing applications to competitors. Marketing wants to drop it to $300. Legal says we can as long as the pet addendum clearly states it's non-refundable (unlike what we currently say, which is that it IS refundable). I need legal sign-off on the "non-refundable" language before we publish.

Can you both review the attached draft addendum and get back to me by EOD Wednesday?

Also, Marcus – can you fix the FAQ? I know there are some inconsistencies in there from when we rushed it for the website launch.

Linda Vasquez
Director of Operations | Nexus Property Group
📞 (800) 555-0192 ext. 204 | 📧 l.vasquez@nexuspropertygroup.com
*Confidential: This message may contain privileged information intended only for the addressee.*

---

------- Reply -------
From: Jessica Hoffman <j.hoffman@nexuspropertygroup.com>
To: Linda Vasquez <l.vasquez@nexuspropertygroup.com>
CC: Marcus Webb <m.webb@nexuspropertygroup.com>; Robert Tan <r.tan@nexuspropertygroup.com>
Date: Monday, November 6, 2023 11:47 AM
Subject: RE: URGENT: Policy updates needed before Jan 1

Linda,

Got it. A few questions before I touch the policy doc:

1. The FAQ currently says the late fee max is $250 (I know, I know – it's wrong, Marcus put that in during the site rush). Does the new $150 cap replace that, or do we want to fix it to the current $200 first and then update again to $150 in January? I'd rather just update to $150 now and add an "effective January 1, 2024" note. Less confusing for tenants.

2. On the pet deposit going non-refundable: I want to flag that several current tenants were told verbally (and possibly in writing via their welcome packets) that the pet deposit IS refundable. If we change this, it only applies to new leases going forward, right? Not retroactively? Want to confirm before someone calls and we look like we don't know our own policy.

3. The application fee discrepancy – did we ever resolve whether it's $25 or $30 for expedited processing? I've left a comment on the FAQ draft but haven't heard back.

4. Can someone send me the new policy text so I can update both the main manual AND the FAQ in one pass? I don't want to do it twice.

Thanks
Jess

---

------- Reply -------
From: Marcus Webb <m.webb@nexuspropertygroup.com>
To: Jessica Hoffman <j.hoffman@nexuspropertygroup.com>; Linda Vasquez <l.vasquez@nexuspropertygroup.com>
CC: Robert Tan <r.tan@nexuspropertygroup.com>
Date: Monday, November 6, 2023 2:33 PM
Subject: RE: URGENT: Policy updates needed before Jan 1

Jess –

On the $250 thing: yeah that was my bad, I was copy/pasting from the old Oakland property template which had a different fee structure. Should have caught it before go-live. Sorry.

The expedited fee: I just checked the signed contract with CreditSafe (our screening vendor) and the cost-pass-through is $25, not $30. The $30 was from a draft before we finalized the vendor. Policy doc is right, FAQ is wrong. I'll fix it.

I'll also remove the duplicate pet question. I honestly don't know how that got in there twice.

One other thing I noticed while I was in the FAQ – the credit score section is wrong. We say 650 minimum and 600–649 for the extra deposit tier. Policy says 620 and 580–619. Jess you left a comment on it but it's still live on the site. Can we just take the FAQ offline until we do a full pass? I'd rather have no FAQ than wrong information publicly accessible.

Marcus

---

------- Reply -------
From: Linda Vasquez <l.vasquez@nexuspropertygroup.com>
To: Marcus Webb <m.webb@nexuspropertygroup.com>; Jessica Hoffman <j.hoffman@nexuspropertygroup.com>
CC: Robert Tan <r.tan@nexuspropertygroup.com>; Sarah Kim <s.kim@nexuspropertygroup.com>
Date: Monday, November 6, 2023 4:05 PM
Subject: RE: URGENT: Policy updates needed before Jan 1

Marcus – DO NOT take the FAQ offline without talking to me first. Marketing will lose their minds. We get 300+ visitors a day to that page.

Let's do a rapid patch:
- Fix the credit score (Marcus)
- Fix the expedited fee to $25 (Marcus)
- Remove duplicate pet question (Marcus)
- Add a note that late fee section is "under review, updated terms effective Jan 1" (Jess)

Sarah – I'm adding you here. Can you work with Marcus to get those FAQ fixes live by Wednesday? Nothing else changes until we have legal sign-off on the pet deposit language.

Robert – where are we on the legal review? We need the non-refundable pet deposit language by Wednesday COB at the latest.

Linda

---

------- Reply -------
From: Robert Tan <r.tan@nexuspropertygroup.com>
To: Linda Vasquez <l.vasquez@nexuspropertygroup.com>
CC: Marcus Webb <m.webb@nexuspropertygroup.com>; Jessica Hoffman <j.hoffman@nexuspropertygroup.com>; Sarah Kim <s.kim@nexuspropertygroup.com>
Date: Tuesday, November 7, 2023 9:58 AM
Subject: RE: URGENT: Policy updates needed before Jan 1

Linda –

Legal review is in progress. A few things from our end:

1. **Non-refundable pet deposit**: Confirmed this is permissible under CA law as long as it is clearly labeled as a fee (not a deposit) in the lease addendum. Recommendation: rename it "Pet Acceptance Fee" ($300, non-refundable) rather than "pet deposit" to avoid confusion with the refundability rules that attach to deposits under Civil Code § 1950.5. I'll send revised addendum language today.

2. **Retroactivity**: Jess is correct. The fee change applies to new leases and renewals executed after the effective date only. Existing tenants with the old pet deposit structure are grandfathered at $500 refundable until their lease renews.

3. **Late fee restructure**: New flat structure ($75 + $75 = $150 max) is compliant. Just make sure the new policy removes ALL per-day accrual language. If any per-day language survives in any version of the doc (including old welcome packets, email templates, etc.) it creates liability. I'd recommend a full template audit.

4. One thing I want to flag for Linda separately (calling you this afternoon): there is a pending complaint from a tenant in Building C who claims they were charged the per-day late fees in excess of $200 last year. I don't think this rises to formal dispute territory yet but we should discuss. Do not put anything about this in writing.

Robert Tan
General Counsel | Nexus Property Group
*Attorney-client privilege may apply to this communication.*

---

------- Reply -------
From: Sarah Kim <s.kim@nexuspropertygroup.com>
To: Marcus Webb <m.webb@nexuspropertygroup.com>
Date: Tuesday, November 7, 2023 10:44 AM
Subject: RE: URGENT: Policy updates needed before Jan 1

Hey Marcus

Can you send me login to the CMS? I don't think I have access to the FAQ page. Also what's the name of that Thai place near the office you mentioned? Asking for the team lunch on Thursday lol

Sarah

---

------- Reply -------
From: Marcus Webb <m.webb@nexuspropertygroup.com>
To: Sarah Kim <s.kim@nexuspropertygroup.com>
Date: Tuesday, November 7, 2023 11:02 AM
Subject: RE: URGENT: Policy updates needed before Jan 1

Ha. Thai Garden on 5th, get the pad see ew. CMS login coming to you via 1Password now.

Changes will be live Wednesday morning. I'll flag Linda when done.

Marcus

---

*[End of exported thread]*
*Export includes 7 of 7 messages. Attachments not included in this export.*
*Exported by: J. Hoffman | For: RAG system ingestion - policy docs folder*
