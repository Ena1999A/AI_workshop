# [SCRAPED WEB PAGE – raw markdown export]
# Source: https://www.nexuspropertygroup.com/properties/harbor-towers/2br-unit-12c
# Scraped: 2024-01-03 02:17:44 UTC
# Scraper: nexus_site_crawler v0.4.2
# WARNING: Contains full page HTML converted to markdown. Navigation, ads, and footer included.

---

[SKIP TO MAIN CONTENT] [SKIP TO NAVIGATION] [ACCESSIBILITY OPTIONS]

**NEXUS PROPERTY GROUP**
[Home] [Properties] [Apply Now] [Tenant Portal] [Contact] [☰ Menu]

🔍 Search properties...

---

[BANNER AD SLOT – INTERNAL PROMO]
**LIMITED TIME: Apply before January 31st and get your first month's application fee waived on select units! Ask us how.**
[LEARN MORE] [DISMISS]

---

[BREADCRUMB: Home > Properties > Harbor Towers > 2 Bedroom Units > Unit 12C]

---

# Harbor Towers – 2 Bedroom / 2 Bath | Unit 12C

**$2,650 / month** | Available: February 1, 2024

[APPLY NOW – $55 APPLICATION FEE] [SCHEDULE A TOUR] [SAVE THIS LISTING ♡] [SHARE ↗]

---

[IMAGE GALLERY: 14 photos]
*[Photo 1: Living room with hardwood floors]*
*[Photo 2: Kitchen with quartz countertops]*
*[Photo 3: Primary bedroom]*
*[Photo 4: Second bedroom / home office setup]*
*[Photo 5–14: See full gallery]*

[VIEW ALL 14 PHOTOS] [VIRTUAL TOUR AVAILABLE – CLICK TO LAUNCH]

---

## Unit Overview

| Feature | Detail |
|---|---|
| Unit | 12C |
| Floor | 12 |
| Bedrooms | 2 |
| Bathrooms | 2 (full) |
| Square Footage | 1,087 sq ft |
| Monthly Rent | $2,650 |
| Available | February 1, 2024 |
| Lease Terms | 12 months (preferred) / 6 months (+ $200/mo surcharge) |
| Pet Friendly | Yes (see pet policy) |
| Parking | 1 assigned space included; additional available $125/mo |
| Laundry | In-unit washer/dryer |
| Air Conditioning | Central A/C |
| Heating | Forced air |
| View | Ocean partial view (east-facing) |

---

## About This Unit

Welcome to Unit 12C at Harbor Towers, one of Nexus Property Group's most sought-after floor plans. This beautifully appointed 2-bedroom, 2-bathroom home offers 1,087 square feet of thoughtfully designed living space on the 12th floor of our flagship property at 1400 Harbor Blvd, Coastal City.

The open-concept living and dining area flows seamlessly into a chef-inspired kitchen featuring quartz countertops, stainless steel appliances, and a breakfast bar — perfect for entertaining or working from home. The primary suite includes a walk-in closet and en-suite bath with dual vanity. The second bedroom is spacious enough for a queen bed and doubles as an ideal home office.

Hardwood floors throughout. Floor-to-ceiling windows bring in abundant natural light. Smart thermostat included.

---

[INLINE PROMO BOX]
**🏠 Thinking about applying?**
Our average approval time is under 3 business days. Apply now and secure your spot before this unit is gone.
[APPLY NOW →]

---

## Building Amenities

- 24-hour front desk / concierge
- Rooftop deck with ocean views and BBQ stations
- Fitness center (5th floor, open 5am–11pm)
- Co-working lounge (3rd floor, open 24/7 with fob access)
- Package lockers (Amazon Hub)
- Bike storage (basement level B2)
- EV charging stations (8 Level 2 chargers, $0.18/kWh)
- Dog washing station
- Guest parking (3 spaces, validated 2 hrs free)
- On-site property management office (Mon–Fri 9am–6pm, Sat 10am–4pm)

---

## Pricing & Fees

**Monthly rent:** $2,650
**Security deposit:** $3,975 (1.5x monthly rent, per standard policy)
**Application fee:** $55 per adult applicant (non-refundable)
**Parking:** Included (1 space); additional $125/month
**Pet rent:** $50/month (dog); $35/month (cat) — see pet policy
**Pet deposit:** $300 per pet

*Note: Pricing and availability are subject to change without notice. Advertised rent reflects 12-month lease term. Month-to-month and 6-month lease terms available at a premium.*

---

[SIMILAR UNITS YOU MAY LIKE]

→ Unit 8A – 2BR/1BA – $2,350/mo – Available Now
→ Unit 15D – 2BR/2BA – $2,750/mo – Available March 1
→ Unit 3F – 1BR/1BA – $1,875/mo – Available February 15

[VIEW ALL AVAILABLE UNITS]

---

## Neighborhood

Harbor Towers is located in the heart of Coastal City's waterfront district, steps from:

- Harbor Walk (0.1 mi)
- Blue Line Metro Station – Harbor/5th (0.3 mi)
- Coastal City Farmers Market (Saturdays, 0.2 mi)
- Whole Foods Market (0.4 mi)
- Coastal City Medical Center (1.2 mi)

Walk Score: 94 | Transit Score: 88 | Bike Score: 76

[VIEW ON MAP] [EXPLORE NEIGHBORHOOD]

---

[INLINE AD – THIRD PARTY]
*Moving soon? Get free quotes from top-rated local movers. Nexus Property Group is not affiliated with and does not endorse any third-party moving companies.*
[GET FREE QUOTES – MoveEasy.com]

---

## Apply for This Unit

Ready to make Harbor Towers your home? Here's what you'll need:

- Government-issued photo ID (all adults 18+)
- Proof of income (2 months pay stubs or equivalent)
- Completed application (each adult, $55 fee)
- We require income of 3x the monthly rent ($7,950/month gross)
- Minimum credit score: 620

Processing time: 2–3 business days (expedited 24hr processing: $25 additional)

[START YOUR APPLICATION →]

*By applying, you authorize Nexus Property Group to run a credit and background check. Application fees are non-refundable.*

---

[SHARE THIS LISTING]
[Facebook] [Twitter/X] [WhatsApp] [Copy Link] [Email a Friend]

---

[RECENTLY VIEWED]
*Unit 9B – 1BR – $1,920/mo*
*Unit 14A – Studio – $1,500/mo*

---

## Contact Us

Have questions? We're here to help.

📞 (800) 555-0192
📧 leasing@nexuspropertygroup.com
🕐 Mon–Fri 9am–6pm | Sat 10am–4pm

[SEND US A MESSAGE]
*[Contact form placeholder – embedded form not captured in scrape]*

---

[FOOTER NAVIGATION]
[Home] [About Nexus] [Our Properties] [Apply Now] [Tenant Portal] [Careers] [Investor Relations] [Press] [Contact Us]

[LEGAL]
[Privacy Policy] [Terms of Use] [Accessibility Statement] [Fair Housing Notice] [Do Not Sell My Personal Information] [Cookie Preferences]

**Fair Housing:** Nexus Property Group is an Equal Housing Opportunity provider. We do not discriminate on the basis of race, color, national origin, religion, sex, familial status, disability, sexual orientation, gender identity, or any other characteristic protected by law.

© 2024 Nexus Property Group LLC. All rights reserved. 1400 Harbor Blvd, Suite 900, Coastal City, CA 90210.

*Listing information is deemed reliable but not guaranteed. All measurements are approximate. Photos may not represent current unit condition.*

---

[SCHEMA MARKUP – RAW – NOT VISIBLE TO USERS BUT CAPTURED BY SCRAPER]
```json
{
  "@context": "https://schema.org",
  "@type": "Apartment",
  "name": "Harbor Towers Unit 12C",
  "description": "2 bedroom 2 bathroom apartment at Harbor Towers, Coastal City",
  "floorSize": { "@type": "QuantitativeValue", "value": 1087, "unitCode": "FTK" },
  "numberOfRooms": 2,
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "1400 Harbor Blvd Unit 12C",
    "addressLocality": "Coastal City",
    "addressRegion": "CA",
    "postalCode": "90210"
  },
  "offers": {
    "@type": "Offer",
    "price": 2650,
    "priceCurrency": "USD",
    "priceSpecification": { "billingDuration": "P1M" }
  }
}
```
[END SCHEMA MARKUP]

[ANALYTICS PIXEL – HIDDEN]
<!-- Google Tag Manager / Meta Pixel / etc. – not rendered but captured -->
<!-- Last CMS edit: Sarah Kim, 2024-01-02 -->
<!-- CMS template: property-listing-v2.3 -->
<!-- A/B test variant: B (CTA button color = coral) -->
[END ANALYTICS]
