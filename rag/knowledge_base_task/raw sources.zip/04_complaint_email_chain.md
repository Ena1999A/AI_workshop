# [EMAIL EXPORT] Tenant Complaint – Unit 4B, Harbor Towers – Late Fees & Deposit Dispute
*Exported from Helpdesk / Zendesk ticket #NPG-2023-8841*
*Tenant: David & Anika Reyes | Unit: 4B, Harbor Towers, 1400 Harbor Blvd*
*Ticket status: ESCALATED – UNRESOLVED as of export date 2024-01-05*

---

------- Original Message -------
From: Anika Reyes <anikareyes84@gmail.com>
To: leasing@nexuspropertygroup.com
Date: Wednesday, October 18, 2023 7:22 PM
Subject: Formal Complaint – Unfair Late Fees and Deposit Issue

To Whom It May Concern,

I am writing to formally complain about the way Nexus Property Group has handled our account. My husband David and I have lived at Harbor Towers Unit 4B for three years and have never had a problem until this year.

Here is what happened:

1. **September rent late fee**: Our rent was paid on September 7th. According to our lease, the grace period is 5 days, which would make September 6th the last day without a late fee. We paid on the 7th, so a $75 late fee was applied, which we accept. HOWEVER, we were also charged an additional $80 ($8/day for 10 days) on top of the flat fee. Our lease addendum says the per-day rate is $8/day, not $10/day. Your policy document on the website says $10/day. Which one is right? Why are there two different amounts? We were charged the higher rate.

2. **Total charge**: Our September statement shows $155 in late fees. The policy on your website says the maximum is $200. Our lease says the maximum is $150. We were charged $155 which exceeds what our own lease says the max is. This seems illegal.

3. **Pet deposit**: When we moved in three years ago, your leasing agent (I believe her name was Carla, she no longer works there) told us our $500 pet deposit for our dog Murphy would be fully refunded when we move out as long as there's no damage. Now I'm seeing in a newer version of the FAQ that the pet deposit might not be refundable? Can you please confirm in writing that our pet deposit is still refundable per our original agreement?

4. **Communication**: I have called the office three times in the last two weeks and been told someone will call me back. Nobody has called me back. This is unacceptable.

We love living here and do not want to make this into a legal issue. We just want to be treated fairly and to get clear, accurate information. Please respond within 5 business days.

Anika Reyes
Unit 4B, Harbor Towers
(555) 304-8812

---

------- Reply -------
From: Sarah Kim <s.kim@nexuspropertygroup.com>
To: anikareyes84@gmail.com
Date: Friday, October 20, 2023 3:14 PM
Subject: RE: Formal Complaint – Unfair Late Fees and Deposit Issue
Ticket: #NPG-2023-8841

Dear Ms. Reyes,

Thank you for reaching out. I apologize for the delay in responding and for the difficulty in reaching our office by phone.

I have reviewed your account and wanted to address your concerns:

1. **Late fee rate ($8 vs $10)**: You are correct that there is a discrepancy. Your original lease addendum (signed October 2020) states $8/day. Our current published policy states $10/day. The terms of YOUR SIGNED LEASE take precedence over our general policy page. You should have been charged $8/day, not $10/day. I am processing a credit of $20 to your account (the difference between $8x10 and $10x10 days) today.

2. **Late fee maximum ($150 vs $200)**: Again, your signed lease cap of $150 takes precedence. Your total late fee charge of $155 exceeded your lease's stated maximum. I am processing an additional credit of $5 to bring your total late fee for September to $150. I apologize for this error.

3. **Pet deposit refundability**: I have confirmed with our Director of Operations that your pet deposit of $500, paid under your October 2020 lease, is fully refundable under the terms of your original agreement. Any changes to our pet deposit policy apply to new leases only and do NOT affect your existing agreement. You have this confirmed in writing via this email.

4. **Callback issue**: I sincerely apologize. I have flagged this with our front desk team. If you need to speak with someone, please call and ask for me directly (Sarah Kim, ext. 218).

Total credit being applied to your account: $25.
Your account balance after credit: $0 (rent for October is not yet due).

Thank you for your patience and for being a valued long-term tenant.

Sarah Kim
Tenant Relations | Nexus Property Group
(800) 555-0192 ext. 218

---

------- Reply -------
From: Anika Reyes <anikareyes84@gmail.com>
To: Sarah Kim <s.kim@nexuspropertygroup.com>
Date: Friday, October 20, 2023 6:47 PM
Subject: RE: Formal Complaint – Unfair Late Fees and Deposit Issue

Sarah,

Thank you for the fast response and for fixing the charges. I appreciate that.

However I need to raise one more thing I noticed when I was looking back through our paperwork. In February 2022, we received a letter from Nexus saying our rent would increase by 6% at our March renewal. We renewed because we didn't want to move. But I just found out that the Coastal City Rent Stabilization Ordinance caps increases at 5% or CPI+2%. The CPI in 2022 was around 8%, so CPI+2% would have been about 10%... so 6% would have been within the cap? I think? I'm not sure I'm reading this right.

My brother-in-law is a paralegal and he says we may have been overcharged but honestly I'm not sure he's reading it right either. Can you explain how the rent increase was calculated? I just want to understand. I'm not trying to sue anyone, I'm just confused.

Also – is the FAQ on your website current? There are some numbers on there that don't match what you told me today. Specifically the credit score minimums look different from what I remember being told when we applied.

Thanks again for the $25 credit.

Anika

---

------- Internal Note (not sent to tenant) -------
From: Sarah Kim <s.kim@nexuspropertygroup.com>
To: Linda Vasquez <l.vasquez@nexuspropertygroup.com>
Date: Monday, October 23, 2023 9:05 AM
Subject: FWD: Ticket #NPG-2023-8841 – Reyes complaint ESCALATION

Linda,

Flagging this one for you. The tenant (Anika Reyes, 4B Harbor Towers) is now asking questions about the 6% rent increase from March 2022. I've confirmed with Robert (separately) that the 6% increase was actually within the RSO limits because it was calculated against the prior year's CPI at the time of notice (February 2022 CPI data showed ~4%, making CPI+2% = 6%, which is exactly what we charged). So technically we're fine. But she's getting advice from a paralegal family member and I want to make sure we're not exposed.

I've resolved the $25 credit issue and confirmed her pet deposit refundability in writing (which I should have checked with you first, sorry – but I've seen the lease, it does say refundable, and we've confirmed that older leases are grandfathered).

How do you want me to handle the rent increase question? Do I explain the CPI calculation or just confirm it was within legal limits and leave it there? Robert said not to put things in writing about anything dispute-adjacent.

Also – she asked about the FAQ. I did not respond to that part. Marcus is supposedly fixing it this week.

Sarah

---

------- Reply from tenant -------
From: Anika Reyes <anikareyes84@gmail.com>
To: Sarah Kim <s.kim@nexuspropertygroup.com>
Date: Thursday, October 26, 2023 11:19 AM
Subject: RE: Formal Complaint – Following up

Sarah,

I haven't heard back on my questions about the rent increase from last week's email. Can you please respond? It's been almost a week.

Also Murphy (our dog) knocked over a lamp and broke it, just so you know that's not a maintenance issue, just mentioning in case you see glass in the inspection photos eventually lol. The lamp was ours.

Just want an update on the rent increase question.

Thank you,
Anika

---

------- Reply -------
From: Sarah Kim <s.kim@nexuspropertygroup.com>
To: Anika Reyes <anikareyes84@gmail.com>
Date: Thursday, October 26, 2023 2:40 PM
Subject: RE: Formal Complaint – Following up

Dear Ms. Reyes,

Apologies for the delayed response. Regarding the March 2022 rent increase: after reviewing our records, the 6% increase applied to your unit was within the limits set by the Coastal City Rent Stabilization Ordinance, based on the Consumer Price Index data available at the time of notice (February 2022). The applicable cap was CPI + 2%, which at that time permitted an increase of up to 6%. Your increase was exactly at that cap.

If you have further questions about the RSO or how CPI is calculated, the City of Coastal City Housing Department maintains a public record of annual allowable increases at [city website].

I hope this resolves your outstanding questions. Your account is in good standing and we appreciate your continued tenancy.

Sarah Kim
Tenant Relations | Nexus Property Group

---

------- Reply -------
From: Anika Reyes <anikareyes84@gmail.com>
To: Sarah Kim <s.kim@nexuspropertygroup.com>
Date: Thursday, October 26, 2023 5:02 PM
Subject: RE: Formal Complaint – Following up

OK, thank you. That makes sense actually. My brother-in-law was looking at the wrong year's CPI. We're good.

Thanks for all your help Sarah. Sorry if I came across harsh in the first email, it was a stressful week.

Anika

---

*[End of ticket thread]*
*Ticket #NPG-2023-8841 marked RESOLVED by: S. Kim | Date: 2023-10-27*
*Resolution notes: $25 credit applied. Pet deposit refundability confirmed for legacy lease. Late fee discrepancy corrected. Rent increase confirmed compliant. Tenant satisfied.*
