# NEXUS PROPERTY GROUP
## Tenant Leasing Policy Manual
### Version 3.1 | Last Updated: March 2022
---
**NEXUS PROPERTY GROUP | 1400 Harbor Blvd, Suite 900, Coastal City, CA 90210 | Tel: (800) 555-0192 | www.nexuspropertygroup.com**
*This document is the property of Nexus Property Group. Unauthorized reproduction is prohibited.*

---

[NAV: Home > Policies > Leasing Manual > v3.1]

---

# NEXUS PROPERTY GROUP
## Tenant Leasing Policy Manual
### Version 3.1 | Last Updated: March 2022

---

## Table of Contents
1. Eligibility Requirements
2. Application Process
3. Security Deposits
4. Rent Payment Policies
5. Lease Renewal & Termination
6. Pet Policy
7. Maintenance & Repairs
8. Guest Policy
9. Subletting Rules
10. Dispute Resolution

---

**NEXUS PROPERTY GROUP | 1400 Harbor Blvd, Suite 900, Coastal City, CA 90210 | Tel: (800) 555-0192**
*For internal distribution only. © 2022 Nexus Property Group. All rights reserved.*

---

## 1. Eligibility Requirements

All prospective tenants must satisfy the following criteria prior to lease execution. Failure to meet any single criterion may result in application denial at the sole discretion of Nexus Property Group management.

**1.1 Income Verification**

Applicants must demonstrate gross monthly income equal to or exceeding three (3) times the monthly rent amount. Acceptable forms of income documentation include:

- Pay stubs (most recent 2 months)
- Tax returns (most recent 2 years) 
- Bank statements (most recent 3 months)
- Offer letters (for new employment, subject to verification)
- Government benefit award letters

Self-employed applicants must provide two (2) years of tax returns AND bank statements for the preceding six (6) months.

**1.2 Credit Score**

Minimum credit score: 620 (FICO or equivalent).

Scores between 580â€"619 may be considered with an additional security deposit of one (1) monthâ€™s rent.
Scores below 580 are ineligible unless a qualified co-signer is provided. Co-signer must meet all income and credit requirements independently.

Note: See section 4.2 for exceptions applicable to Section 8 voucher holders.

**1.3 Rental History**

A minimum of two (2) years verifiable rental history is required, OR proof of homeownership. First-time renters may qualify with a co-signer (see 1.2).

Negative rental history factors that may result in automatic denial:
- Eviction filing within the past 5 years
- Outstanding balance owed to a prior landlord
- Two or more late payments in any 12-month period (as reported by prior landlord)

---

**NEXUS PROPERTY GROUP | 1400 Harbor Blvd, Suite 900, Coastal City, CA 90210 | Tel: (800) 555-0192**
*This document is the property of Nexus Property Group. Unauthorized reproduction is prohibited.*

---

## 2. Application Process

**2.1 Application Fee**

A non-refundable application fee of $55.00 per adult applicant (18+) is required at time of submission. This fee covers the cost of credit and background screening.

**2.2 Required Documents**

[ ] Government-issued photo ID (all adults)
[ ] Proof of income (see 1.1)
[ ] Completed application form (all adults)
[ ] Authorization for background/credit check (all adults)
[ ] Pet documentation if applicable (see Section 6)

**2.3 Processing Time**

Standard processing: 2â€"3 business days
Expedited processing (additional $25 fee): 24 hours

Nexus Property Group is not responsible for delays caused by third-party screening providers.

**2.4 Approval Notification**

Approved applicants will receive an email to the address provided on the application. Approved applicants have 48 hours to execute the lease and pay the security deposit. Failure to do so forfeits the unit reservation.

---

## 3. Security Deposits

**3.1 Standard Deposit Schedule**

The following table details security deposit requirements by unit type:

Unit Type | Monthly Rent Range | Standard Deposit | Max Deposit (CA Law)
--- | --- | --- | ---
Studio | $1,200â€"$1,800 | 1.5x monthly rent | 2x monthly rent
1 Bedroom | $1,600â€"$2,400 | 1.5x monthly rent | 2x monthly rent
2 Bedroom | $2,200â€"$3,200 | 1.5x monthly rent | 2x monthly rent
3 Bedroom | $2,800â€"$4,500 | 1.5x monthly rent | 2x monthly rent
Penthouse/Premium | $4,500+ | 2x monthly rent | 2x monthly rent

Note: Pet deposits are additional. See Section 6.3.

**3.2 Deposit Payment**

Security deposits must be paid in full via certified check, money order, or ACH transfer prior to key release. Personal checks are not accepted for deposit payment.

Deposits are held in a separate trust account per California Civil Code Â§ 1950.5.

**3.3 Deposit Return**

Deposits will be returned within 21 days of lease termination, accompanied by an itemized statement of any deductions. Deductible items include:

- Unpaid rent
- Cleaning costs (if unit returned below move-in condition)
- Damage beyond normal wear and tear
- Unpaid utilities billed to tenant

Normal wear and tear is NOT deductible. This includes: minor scuffs on walls, carpet wear in high-traffic areas, small nail holes from picture hanging (maximum 2 per wall).

---

**NEXUS PROPERTY GROUP | 1400 Harbor Blvd, Suite 900, Coastal City, CA 90210 | Tel: (800) 555-0192**
*This document is the property of Nexus Property Group. Unauthorized reproduction is prohibited.*

---

## 4. Rent Payment Policies

**4.1 Due Date & Grace Period**

Rent is due on the 1st of each month. A grace period of five (5) calendar days is provided. Rent received after the 5th is subject to a late fee.

**4.2 Late Fee Schedule**

Late Fee: $75 flat fee applied on the 6th of the month.
Additional accrual: $10/day for each day past the 10th (maximum $200/month).

Section 8 / Housing Choice Voucher holders: Late fees apply only to the tenant-paid portion of rent. The voucher portion is not subject to late fees regardless of when HUD payment is received.

**4.3 Accepted Payment Methods**

Nexus Property Group accepts the following:
- Online portal (nexuspropertygroup.com/pay) â€" preferred
- ACH/bank transfer
- Money order
- Cashierâ€™s check

Cash and personal checks are NOT accepted under any circumstances.

**4.4 NSF / Returned Payments**

Returned payments (NSF) incur a $35 fee per occurrence. After two (2) NSF events in any 12-month period, Nexus Property Group reserves the right to require all future payments via money order or cashierâ€™s check only.

---

## 5. Lease Renewal & Termination

**5.1 Renewal Notice**

Nexus Property Group will provide written notice of lease renewal terms no later than 60 days prior to lease expiration. Tenants must respond in writing within 30 days.

**5.2 Rent Increase Policy**

Annual rent increases are capped per applicable local ordinance. For properties in Coastal City:
- Maximum increase: 5% OR CPI + 2%, whichever is lower (per Coastal City Rent Stabilization Ordinance, effective Jan 2020)
- Minimum notice: 30 days for increases under 10%; 90 days for increases of 10% or more

**5.3 Early Termination**

Early termination by tenant requires:
1. 60 daysâ€™ written notice
2. Early termination fee equal to TWO (2) monthsâ€™ rent
3. Unit returned in move-in condition

Military personnel may terminate early without penalty per the Servicemembersâ€™ Civil Relief Act (SCRA). Documentation required.

**5.4 Non-Renewal by Landlord**

Nexus Property Group may choose not to renew a lease for the following reasons (not exhaustive):
- Material lease violations
- Consistent late payment (3+ late payments in lease term)
- Planned substantial renovation of the unit
- Owner move-in (subject to local ordinance requirements)

---

**NEXUS PROPERTY GROUP | 1400 Harbor Blvd, Suite 900, Coastal City, CA 90210 | Tel: (800) 555-0192**
*This document is the property of Nexus Property Group. Unauthorized reproduction is prohibited.*
*[PAGE BREAK]*
*NEXUS PROPERTY GROUP | Leasing Policy Manual v3.1 | Page 8 of 24*

---

## 6. Pet Policy

**6.1 Permitted Pets**

Nexus Property Group is a pet-friendly community subject to the following restrictions:

Permitted (with approval):
- Dogs: maximum 2, combined weight not to exceed 80 lbs
- Cats: maximum 2
- Small caged animals (hamsters, guinea pigs, birds): maximum 2 cages

NOT permitted under any circumstances:
- Exotic animals (reptiles over 12 inches, primates, venomous species)
- Dogs of the following breeds or mixes: Pit Bull Terrier, Rottweiler, Doberman Pinscher, Akita, Chow Chow, Wolf hybrid
- Farm animals

Service animals and emotional support animals (ESAs) are exempt from breed and weight restrictions per Fair Housing Act requirements. Documentation required.

**6.2 Pet Approval Process**

Submit the following to the leasing office:
- Pet application form (per animal)
- Current vaccination records
- Photo of pet
- Veterinarian contact information

Approval is not guaranteed and may be revoked if the animal causes damage, noise complaints, or safety concerns.

**6.3 Pet Deposit & Fees**

Pet Deposit: $500 per pet (refundable, subject to damage assessment)
Monthly Pet Rent: $50/month per dog; $35/month per cat; $15/month for small caged animals

---

*[Document continues through Section 10. Sections 7â€"10 omitted from this extract.]*

---

**NEXUS PROPERTY GROUP | 1400 Harbor Blvd, Suite 900, Coastal City, CA 90210 | Tel: (800) 555-0192**
*This document is the property of Nexus Property Group. Unauthorized reproduction is prohibited. © 2022 Nexus Property Group. All rights reserved. Printed copies are uncontrolled. Verify version at www.nexuspropertygroup.com/policies*

[FOOTER: Home | Policies | Tenant Portal | Contact Us | Privacy Policy | Terms of Use]
[Cookie Notice: This site uses cookies. By continuing to use this site you agree to our use of cookies. Accept | Manage Preferences]
